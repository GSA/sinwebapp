VERSION = '2.0.0'

default_app_config = 'uaa_client.apps.UaaClientConfig'
